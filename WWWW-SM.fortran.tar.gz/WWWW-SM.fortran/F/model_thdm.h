* model_thdm.h
* declarations for model_thdm.F
* this file is part of FormCalc
* last modified 7 Mar 13 th


#include "model_sm.h"

	RealType Lambda5
	RealType Yuk1, Yuk2, Yuk3

	common /thdmpara/ Lambda5
	common /thdmpara/ Yuk1, Yuk2, Yuk3
