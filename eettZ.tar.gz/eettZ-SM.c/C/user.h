#if 0
	user.h
	the model declarations should be inserted here
	as well as any kind of user definition
	this file is part of FormCalc
	last modified 7 Mar 13 th
#endif


#ifndef USER_H
#define USER_H
// declarations for the whole file (e.g. preprocessor defs)

//#define PARALLEL
//#define SAMURAI

#include "model_mssm.h"

#else
// declarations for every subroutine

//#include "opp.h"

#endif

