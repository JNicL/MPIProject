#define HAVE_LONG_DOUBLE

#define HAVE_POWL

#define HAVE_ERF

#define HAVE_FORK

#define HAVE_SHMGET

#define HAVE_GETLOADAVG


